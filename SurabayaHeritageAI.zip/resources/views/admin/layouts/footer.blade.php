<footer class="bg-gray-800 text-white py-4 md:ml-64">
    <div class="container mx-auto px-4 text-center">
        <p class="text-sm">© {{ date('Y') }} SurabayaAI Admin Panel. Hak Cipta Dilindungi.</p>
    </div>
</footer>