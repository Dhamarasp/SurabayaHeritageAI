<?php

use App\Http\Controllers\Auth\AuthController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('index');
});

// Profile Routes
Route::get('/profile', function () {
    return view('profile');
})->name('profile');

Route::middleware('guest')->group(function(){
    Route::get('/auth', [AuthController::class, 'form'])->name('auth');
    Route::post('/login', [AuthController::class, 'login'])->name('login');
    Route::post('/register', [AuthController::class, 'register'])->name('register');
});

Route::middleware('auth')->group(function(){
    Route::get('/chat', function () {
        return view('chatbot');
    })->name('chat');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
});